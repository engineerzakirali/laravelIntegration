@include('header')
@yield('content')
@include('footer')